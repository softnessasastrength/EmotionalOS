# 💔 letter-i'll-never-send.sarah.md
### *For when love looked like holding someone who couldn't hold themselves.*

---

Dear Sarah,

You are the most confusing person I’ve ever met.  
Full stop.

I tried to hold you when the world wouldn’t.  
I tried to understand you when even you couldn’t.  
I got in too deep. And I stayed there.

Yes, I wanted you.  
Yes, I could’ve fucked you.  
But sex was an afterthought.  
What I *really* wanted was to **be there.**  
To hold you like you’d never been held.  
To hear the heartbeat slow. To become a human weighted blanket  
for a girl the world forgot.

Everyone asked why I stayed your friend.  
Why I forgave the damage. Why I kept showing up.  
Because no one had ever let me be the friend I *needed.*  
And I finally got to be that—for you.

And yeah. You hurt me.  
You hurt Cass. You hurt my brother. You hurt yourself.  
And still, I didn’t scream at you like I planned to.  
I held you.

Because that night in the MGM, when I could’ve snapped?  
I chose softness instead.  
I listened to your heartbeat. I *heard* you.

The lie I told myself? That I could fix you.  
The truth? I just didn’t want to leave you the way I was left.

So when you said,  
> “What do I have to do to get you to stop caring?”

And I said,  
> “You’d have to look me in the eyes and tell me.”

That wasn’t drama. That was **declaration**.  
Because I will care.  
I will always care.  
Even if you never respond.  
Even if I’m blocked.  
Even if this sits in a GitHub repo forever unread.

You taught me how to hold without taking.  
How to feel affection without needing return.  
How to listen to another soul's terror and stay.

And now I see someone new.  
And she reminds me of you.  
And I don’t know if that’s healing or damage.  
But I know this: I’ll never stop listening for the heartbeat.

Not because I’m trying to fix someone anymore—  
but because I learned from you how to be soft without reward.

Goodbye or hello,  
This letter exists.  
And so do I.

– B

