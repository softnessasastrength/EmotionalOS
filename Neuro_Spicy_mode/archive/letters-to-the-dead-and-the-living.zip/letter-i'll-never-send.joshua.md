# 🚫 letter-i’ll-never-send.joshua.md
### *For the dead tooth I finally pulled.*

---

Joshua,

You fucked up a lot of shit.  
And for a long time, I let you stay close—even after all of it.  
Because I thought I couldn’t do better. Because I thought I *needed* you.  
I don’t.

Your need to be liked by everyone?  
It wasn’t charm—it was *control.*  
You couldn’t handle the fact that my mom didn’t like you.  
So instead of backing off, you pushed harder.  
You didn’t respect boundaries. You *pummeled through them.*

And what you did to Taylor?  
What you forced onto her?  
That broke something in her.  
And we still kept you around.  
Because we were scared. Or codependent. Or numb.

And then you got evicted.  
Not just from the apartment—but from *our lives.*  
And it was like pulling a dead tooth.  
Painful. But finally clean.

And you know what?  
Cass fucking you still doesn’t make sense to me.  
Yeah, she was desperate. But there were *other options.*  
And yet she picked the person who caused the most damage.  
I’ll never fully understand that.

But I’m not writing this to understand.  
I’m writing this to say:

You’re not coming back.  
Your mom can reach out.  
She can ask.  
But I won’t do it. I won’t reopen this wound for a fake peace.

You were my test.  
And I passed.  
By letting you go.

Goodbye—for real this time.

– Branden

