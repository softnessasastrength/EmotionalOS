# 🤝 letter-to-my-brother.md
### *For Connor. For what I missed. For what I’m trying to build now.*

---

Connor,

I need to start this with something heavy:

I didn’t treat you right when we were younger.  
I didn’t *see* you—not as a brother, not as a friend, not even as a person with his own light.  
I avoided you. I pushed you away. I made you feel like you didn’t matter.  
And I can’t give you a full why. Not yet.  
But I can tell you this: I regret the fuck out of it.

The truth?  
The family dynamic shifted when you came into the picture.  
And I resented you for it.  
I didn’t know how to love you through that resentment,  
so I chose distance over connection. Coldness over care.  
Small things—but they added up.  
They made you feel unloved.  
And that’s on me.

But I remember the day it shifted.  
It was when I started driving.  
I took you out. We just… *drove.*  
And I started to meet you. Like, actually meet you.  
As a person. As Connor. Not as competition.  
And fuck, dude… I realized how much I had missed.  
And how much I had cost us both.

And then came Sarah.  
And the fucked up mess of it all.  
You got hurt.  
You got *violated*.  
And it happened because of something that spiraled from me and Cass,  
because we didn’t communicate. Because we were playing with fire and didn’t stop to ask who might get burned.

And I’ll carry that forever.

But here’s what else I’ll carry:

You gave me a second chance.  
You *let* me show up.  
You let me rebuild what I tore down.  
You let me drive you, laugh with you, and finally—*finally*—be your goddamn brother.

And I’m here now.  
I’m not letting go.  
Even if we don’t say it out loud, even if we never unpack it fully,  
you need to know: I love you. I’m sorry. And I’m *staying.*

Always.

– B

