# 🕯️ letter-i’ll-never-send.hannah.md
### *For the one that got away—and the piece of me that went with you.*

---

Hannah,

You were the fucking blueprint.

Since kindergarten, you were a constant—  
until you weren’t.  
Not because of us.  
But because my father cheated with your mom.  
Yeah. That’s the nuclear bomb no one told me about.

It wasn’t just our friendship that got wrecked.  
It was the entire bridge between our families,  
and no one gave a fuck what that did to *us.*

Fast-forward.  
Five years ago.  
Drunk. Spiraling.  
I text you.  
You respond.  
And we *rekindle everything.*  
The fire starts.  
And that’s when the **situationship** from hell begins.

Two and a half years of what-the-fuck-are-we.  
No clarity. No labels.  
Just… *us.* Kissing. Fucking. Laughing. Sharing beds. Sharing *everything but a name.*

And every time I tried to say it—*really say it*—I choked.  
Because somewhere deep down, I didn’t believe I deserved you.  
You said you were gay.  
Then you went on dates with men.  
You said you couldn’t be with me.  
Then you’d come closer than anyone else ever did.

What the fuck was that?

You said no without ever saying no.  
You left the door unlocked but never opened it.  
And it fucked with me in ways I’m still unpacking.

You were the first person I truly loved.  
And you never gave it a chance.  
And when I finally asked for the ring back,  
something in me *finally snapped free.*  
That was the death of the feelings.

But not the confusion.  
Not the resentment.  
Not the imprint you left on my goddamn soul.

You taught me to doubt what people say when they say  
> “I’m just not into men.”  
Because I believed you.  
Until you contradicted it—again and again.  
And now Cass says the same thing.  
And I don’t believe her. Because of *you.*

You shaped how I mistrust ambiguity.  
You shaped how I crave clarity.  
You shaped how I *need to hear it said plain,* or I spiral.

We were something.  
I wasn’t crazy.  
And all I ever wanted was to try.  
You couldn’t give me that.

And now?  
I don’t need it.  
But I needed to say this.

Goodbye, Hannah.  
You were the one that got away.  
And now I get to move forward.

– Branden

