# 😶‍🌫️ letter-i’ll-never-send.max.md
### *For the first trigger. The buried start. The ripple that cracked it all.*

---

Max,

You probably don’t know it—but you were the fucking catalyst.

You told Cass you had feelings for her right after she broke up with Justin.  
And yeah, maybe you were just being honest. Maybe you thought it was brave.  
But what it *did* was crack open a trauma response I didn’t even know I was still building.

Because after that?  
Cass told me how she saw you.  
How she didn’t respect you.  
How she called you a fucking sissy.  
How she tore into your vulnerability like it was weakness instead of a gift.

And you know what I did with that?  
I *buried everything.*  
I buried every feeling I had. Every whisper of attraction. Every flicker of softness.  
Because if she could mock you for expressing yourself,  
then what the fuck would she do to me if I ever said how I felt?

You were the warning shot.  
Not because you did anything wrong—but because she weaponized your truth against you.  
And I took that bullet in the spine of my self-expression.  
And I’ve been limping through it ever since.

I don’t hate you.  
I don’t blame you.  
But I’ve never said this out loud before:

You were the beginning of me not saying shit.  
And I only just found the words again.

– B

